package com.cours.android_tp1_elisagougerot

import android.content.Context
import android.graphics.Color
import android.util.AttributeSet
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout


const val DEFAULT_TEXT_COLOR = Color.BLACK
const val DEFAULT_SRC = R.drawable.my_picture


class MyCustomView(context: Context, attrs: AttributeSet) : LinearLayout(context, attrs) {

    private var customEditText : EditText
    private var customImageView : ImageView

    init {

        inflate(context, R.layout.custom_component, this)

        customEditText = findViewById(R.id.customEditText)
        customImageView = findViewById(R.id.customImageView)

        setupAttributes(attrs)
    }

    private fun setupAttributes(attrs: AttributeSet?) {
        val typedArray = context.theme.obtainStyledAttributes(attrs, R.styleable.MyCustomView, 0, 0)
        customEditText.setTextColor(typedArray.getColor(R.styleable.MyCustomView_textColor, DEFAULT_TEXT_COLOR))
        customEditText.setText(typedArray.getString(R.styleable.MyCustomView_text))
        customImageView.setImageResource(typedArray.getResourceId(R.styleable.MyCustomView_src, DEFAULT_SRC))

        typedArray.recycle()
    }

}

